<?php
$conex = mysqli_connect("localhost","root","","admin_v2");